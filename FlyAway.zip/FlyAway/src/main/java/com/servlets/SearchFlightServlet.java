package com.servlets;
import com.admin.dao.SearchFlightDao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class SearchFlightServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String sourceName=request.getParameter("sourceName");
		String destinationName=request.getParameter("destinationName");
		
		
		if(sourceName.equals(destinationName)) {
			out.println("Invalid Choice. Source and Destination can not be same!!! <br><br>");
			out.println("<a href=searchflight.html>Go To SeachFlight</a>");
			return;
		}else {
			
			try {
				if(SearchFlightDao.checkFlight(sourceName,destinationName)) {
					RequestDispatcher rd=request.getRequestDispatcher("user_registration.html");
					rd.forward(request, response);
				}else {
					RequestDispatcher rd=request.getRequestDispatcher("searchFlight.html");
					rd.include(request, response);
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

}
