package com.admin.dao;
import java.sql.*;

public class LoginDao {
	
	public static boolean checkAdmin(String email, String password) throws ClassNotFoundException, SQLException {
		boolean status=false;
		
		String url="jdbc:mysql://localhost:3306/FlyAway?user=root";
		String user="root";
		String pass="sush@1995";
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn=DriverManager.getConnection(url,user,pass);
		PreparedStatement ps=conn.prepareStatement("select * from Admin_Login where email=? and password=?");
		ps.setString(1, email);
        ps.setString(2, password);
        ResultSet rs =ps.executeQuery();
        status = rs.next();
        
        return status;
        
    
        }

	
	

}
