package com.admin.dao;
import java.sql.*;

public class SearchFlightDao {
	
	public static boolean checkFlight(String sourceName, String destinationName) throws ClassNotFoundException, SQLException {
		boolean status=false;
		
		String url="jdbc:mysql://localhost:3306/FlyAway?user=root";
		String user="root";
		String pass="sush@1995";
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn=DriverManager.getConnection(url,user,pass);
		PreparedStatement ps1=conn.prepareStatement("select * from Source_Place where Source_name=?");
		PreparedStatement ps2=conn.prepareStatement("select * from Destination_Place where Destination_name=?");
		ps1.setString(1, sourceName);
		ps2.setString(1, destinationName);
        ResultSet rs1 =ps1.executeQuery();
        ResultSet rs2 =ps2.executeQuery();
        status = rs1.next();
        status = rs2.next();
        
        return status;
        
    
        }

	
	

}
